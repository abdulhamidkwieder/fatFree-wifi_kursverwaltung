<?php
require_once "vendor/autoload.php";
$f3 = \Base::instance();

require_once 'init.php';
require_once 'routes.php';

$f3->run();