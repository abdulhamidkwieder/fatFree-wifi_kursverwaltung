<?php
/* 
    Projekt initalisieren
*/

////// Resourcen Pfade setzen
$f3->set('resources', '/resources/');
$f3->set('css', $f3->get('resources') . 'css/');
$f3->set('js', $f3->get('resources') . 'js/');
$f3->set('images', $f3->get('resources') . 'img/');
$f3->set('contents', '/views/contents/');

/////// Projekt Variablen
$f3->set('projekt', 'Wifi Kursverwaltung');
$f3->set('delimiter', ' | ');
$f3->set('defaultcss', ['normalize.css', 'skeleton.css', 'kursverwaltung.css']);

/////// Database
$f3->set('DB', new DB\SQL(
    'mysql:host=localhost;port=3306;dbname=wifi_kursverwaltung',
    'root',
    ''
));