<?php
namespace Controller;

class KundenController extends Controller {
    private $validationConf = [
        'vorname' =>    'required|valid_name|max_len,255',
        'nachname' =>   'required|valid_name|max_len,255',
        'strasse' =>    'required|max_len,255',
        'hausnummer' => 'required|max_len,25',
        'plz' =>        'required|max_len,255',
        'ort' =>        'required|max_len,255',
        'land' =>       'required|integer',
        'email' =>      'required|valid_email',
        'tel' =>        'required|max_len, 120'
    ];

    public function __construct($f3, $params)
    {
        // Initialisierung benötigter Variablen
        parent::__construct($f3, $params);
        $f3->set('errors', []);
        $f3->set('msg', '');
        $f3->set('posted', false);
    }

    /**
     * Index, bzw. default page für Kunden
     *
     * @param object $f3
     * @param array $params
     * @return void
     */
    public function render($f3, $params) {
        $km = new \Model\KundenModel($f3);
        $kunden = $km->getKunden();
        $f3->set('kunden', $kunden);
        $f3->set('sitetitle', 'Kunden Übersicht');
        $f3->set('includecss',  $this->getCssFilesPaths());
        $f3->set('content', $f3->get('contents') . 'kunden_show.html');
        echo \Template::instance()->render('views/index.html');
    }
    
    /**
     * Neuen Kunden anlegen
     *
     * @param [type] $f3
     * @param [type] $params
     * @return void
     */
    public function renderNew($f3, $params) {
        $f3->set('sitetitle', 'Neuer Kunde');
        $f3->set('includecss',  $this->getCssFilesPaths());
        $f3->set('content', $f3->get('contents') . 'kunden_new.html');
        echo \Template::instance()->render('views/index.html');
    }

    public function posted($f3, $params) {
        $f3->set('sitetitle', 'Neuer Kunde');
        $f3->set('includecss',  $this->getCssFilesPaths());
        // Leer initialisieren
        $msg = '';
        $errors = [];
        
        if (!empty($_POST)) {
            $gump = new \GUMP('de');
            $_POST = $gump->sanitize($_POST);
            $gump->validation_rules($this->validationConf);
            // TODO: evtl. filter setzen

            $validated_data = $gump->run($_POST);

            if ($validated_data === false) {
                $errors = $gump->get_errors_array();
                $f3->set('posted', true);
            }
            else {
                $km = new \Model\KundenModel($f3);
                // Bereinigte Daten in DB speichern
                $km->addKunde($validated_data);
                // TODO: im Model prüfen, ob das Anlegen in der DB erfoglreich war
                $msg = 'Der neue Datensatz wurde erfolgreich angelegt.';
            }
        }
        
        $f3->set('errors', $errors);
        $f3->set('msg', $msg);
        

        $this->renderNew($f3, $params);
    }


    public function liste($f3, $params) {
        $km = new \Model\KundenModel($f3);

        $f3->set('sitetitle', 'Kunden liste');
        $f3->set('includecss',  $this->getCssFilesPaths());
        $f3->set('content', $f3->get('contents') . 'kunden_show.html');
        echo \Template::instance()->render('views/index.html');
    }
}