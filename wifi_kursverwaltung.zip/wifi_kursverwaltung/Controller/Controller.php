<?php
namespace Controller;

abstract class Controller {
    protected $cssBasePath = '';
    protected $cssFiles = [];
    protected $jsFiles = [];

    public function __construct($f3, $params) {
        $this->cssFiles = $f3->get('defaultcss');
        $this->cssBasePath = $f3->get('css');
    }


    protected function getCssFilesPaths() {
       $cssFiles = '';
       foreach ($this->cssFiles as $file) {
           $cssFiles .= '<link rel="stylesheet" href="' . 
               $this->cssBasePath .
               $file .
               '">';
       }

       return $cssFiles;
    }
    
    /* Weitere CSS Dateien hinzufügen, z. B. welche, die nur in bestimmten
     Controllern geladen werden sollen. */
    public function addCssFile(string $path) {

    }
}