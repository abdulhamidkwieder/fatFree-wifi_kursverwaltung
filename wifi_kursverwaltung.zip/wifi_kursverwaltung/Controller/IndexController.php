<?php
namespace Controller;

class IndexController extends Controller {
    public function render($f3, $params) {
        // Alle Variablen, die im Template benötigt werden, werden  mit $f3->set ... vorbereitet
        $f3->set('sitetitle', 'Home');
        // Der Pfad zu unserer views/contents/ ... html
        $f3->set('includecss',  $this->getCssFilesPaths());
        $f3->set('content', $f3->get('contents') . 'home.html');
        echo \Template::instance()->render('views/index.html');
    }
}