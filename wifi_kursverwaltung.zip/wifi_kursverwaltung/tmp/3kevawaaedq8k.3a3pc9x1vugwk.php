<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= ($projekt) ?><?= ($delimiter) ?><?= ($sitetitle) ?></title>
    <?= ($this->raw($includecss))."
" ?>
</head>
<body>
    <div class="container">
        <header class="row site-header">
            <h1 class="twelve columns"><?= ($projekt) ?> - <?= ($sitetitle) ?></h1>
        </header>
        <main>
            <?php echo $this->render($content,NULL,get_defined_vars(),0); ?>
        </main>
    </div>

</body>
</html>