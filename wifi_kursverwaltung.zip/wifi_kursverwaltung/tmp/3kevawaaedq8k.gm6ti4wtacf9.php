<style>
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
          text-align: center;
        }
        
        td, th {
          text-align: center;
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }
        
        tr:nth-child(even) {
          text-align: center;
          background-color: #dddddd;
        }
        h2 {
            text-align: center;
        }
        </style>
<br>
<br>
<h2>Kunden</h2>
<br>

<?php foreach (($kunden?:[]) as $kunde): ?>
<table>
    <tr>
        <td>Vor Name</td>
        <td>Nach Name</td>
        <td>Strasse</td>
        <td>Haus Nummer</td>
        <td>Platz</td>
        <td>Ort</td>
        <td>Land</td>
        <td>E-mail</td>
        <td>Telephone</td>
    </tr>
    <tr>
        <th><?= ($kunde['vorname']) ?></th>
        <th><?= ($kunde['nachname']) ?></th>
        <th><?= ($kunde['strasse']) ?></th>
        <th><?= ($kunde['hausnummer']) ?></th>
        <th><?= ($kunde['plz']) ?></th>
        <th><?= ($kunde['ort']) ?></th>
        <th><?= ($kunde['land']) ?></th>
        <th><?= ($kunde['email']) ?></th>
        <th><?= ($kunde['tel']) ?></th>
    </tr>
</table>

<?php endforeach; ?>