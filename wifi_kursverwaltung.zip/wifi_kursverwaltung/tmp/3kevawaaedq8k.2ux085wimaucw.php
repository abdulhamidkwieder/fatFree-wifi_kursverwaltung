<h2>Neuer Kunde</h2>

<?php if ($msg != ''): ?>
    <p class="form-msg"><?= ($msg) ?></p>
<?php endif; ?>

<?php if (empty($errors) == false): ?>
    <p class="error-msg">Das Formular enthält Fehler!</p>
<?php endif; ?>

<form action="" method="post">
    <label for="vorname">Vorname</label>
    <input type="text" name="vorname" id="vorname" value="<?= ($posted && $POST['vorname'] ? $POST['vorname'] : '') ?>">
    <?php if (array_key_exists('vorname', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['vorname']) ?></p>
    <?php endif; ?>
    
    <label for="nachname">Nachname</label>
    <input type="text" name="nachname" id="nachname" value="<?= ($posted && $POST['nachname'] ? $POST['nachname'] : '') ?>">
    <?php if (array_key_exists('nachname', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['nachname']) ?></p>
    <?php endif; ?>

    <label for="strasse">Straße</label>
    <input type="text" name="strasse" id="strasse" value="<?= ($posted && $POST['strasse'] ? $POST['strasse'] : '') ?>">
    <?php if (array_key_exists('strasse', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['strasse']) ?></p>
    <?php endif; ?>

    <label for="hausnummer">Hausnummer</label>
    <input type="text" name="hausnummer" id="hausnummer" value="<?= ($posted && $POST['hausnummer'] ? $POST['hausnummer'] : '') ?>">
    <?php if (array_key_exists('hausnummer', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['hausnummer']) ?></p>
    <?php endif; ?>

    <label for="plz">PLZ</label>
    <input type="text" name="plz" id="plz" value="<?= ($posted && $POST['plz'] ? $POST['plz'] : '') ?>">
    <?php if (array_key_exists('plz', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['plz']) ?></p>
    <?php endif; ?>

    <label for="ort">Ort</label>
    <input type="text" name="ort" id="ort" value="<?= ($posted && $POST['ort'] ? $POST['ort'] : '') ?>">
    <?php if (array_key_exists('ort', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['ort']) ?></p>
    <?php endif; ?>

    <label for="land">Land</label>
    <input type="text" name="land" id="land" value="<?= ($posted && $POST['land'] ? $POST['land'] : '') ?>">
    <?php if (array_key_exists('land', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['land']) ?></p>
    <?php endif; ?>
    
    <label for="email">E-Mail</label>
    <input type="email" name="email" id="email" value="<?= ($posted && $POST['email'] ? $POST['email'] : '') ?>">
    <?php if (array_key_exists('email', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['email']) ?></p>
    <?php endif; ?>
    
    <label for="tel">Telefon</label>
    <input type="text" name="tel" id="tel" value="<?= ($posted && $POST['tel'] ? $POST['tel'] : '') ?>">
    <?php if (array_key_exists('tel', $errors)): ?>
        <p class="fielderror-msg"><?= ($errors['tel']) ?></p>
    <?php endif; ?>
    <br>
    <input class="button-primary" type="submit" value="Senden">
</form>