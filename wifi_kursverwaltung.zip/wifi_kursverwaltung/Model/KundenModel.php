<?php
namespace Model;

class KundenModel {
    protected $db; // Database Connection
    protected $f3;

    public function __construct($f3) {
        $this->f3 = $f3;
        $this->db = $f3->get('DB');
    }

    public function addKunde(array $data) 
    {
        // Prepared statement ausführen
        $this->db->exec(
            'INSERT INTO kunden (vorname, nachname, strasse, hausnummer, plz, ort, land, email, tel) VALUES (:vorname, :nachname, :strasse, :hausnummer, :plz, :ort, :land, :email, :tel)',
            [
                ':vorname' => $data['vorname'],
                ':nachname' => $data['nachname'],
                ':strasse' => $data['strasse'],
                ':hausnummer' => $data['hausnummer'],
                ':plz' => $data['plz'],
                ':ort' => $data['ort'],
                ':land' => $data['land'],
                ':email' => $data['email'],
                ':tel' => $data['tel']
            ]
        );
    }

    public function getKunden() {
        $result = $this->db->exec(
            'SELECT * FROM kunden order by nachname ASC'
        );
       
        return $result;
    }
}