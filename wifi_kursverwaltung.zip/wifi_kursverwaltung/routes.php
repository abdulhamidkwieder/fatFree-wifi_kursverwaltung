<?php
$f3->route('GET /', '\Controller\IndexController->render');
$f3->route('GET /kunden', '\Controller\KundenController->render');
$f3->route('GET /kunden/new', '\Controller\KundenController->renderNew');
$f3->route('POST /kunden/new', '\Controller\KundenController->posted');
/*
TODO: Delete route implementieren
$f3->route('POST /kunden/delete/@kid', '\Controller\KundenController->delete');
$f3->route('POST [ajax] /kunden/delete/@kid', '\Controller\KundenController->deleteAjax'); */